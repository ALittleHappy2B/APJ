package com.shxt.user.service;

import com.shxt.user.dao.UserDao;
import com.shxt.user.dao.UserDaoImpl;
import com.shxt.user.model.User;

public class UserServiceImpl implements UserService {

	private UserDao userDao = new UserDaoImpl();

	@Override
	public User login(String account,String password){
		User user = this.userDao.login(account, password);
		if(user==null){
			throw new RuntimeException("用户名或者密码错误,请重新登录");
		}else{
			if(user.getStatus()!=1){
				throw new RuntimeException("该账号已经被停用,请联系管理员");
			}
			return user;
		}
	}

}
