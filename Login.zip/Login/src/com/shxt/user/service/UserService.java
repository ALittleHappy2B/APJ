package com.shxt.user.service;

import com.shxt.user.model.User;

public interface UserService {

	User login(String account,String password);

}
