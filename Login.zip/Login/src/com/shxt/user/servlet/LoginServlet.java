package com.shxt.user.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.shxt.user.model.User;
import com.shxt.user.service.UserService;
import com.shxt.user.service.UserServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/sys/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 只有请求转发才能访问到WEB-INF文件夹的的JSP页面
		request.getRequestDispatcher("/WEB-INF/jsp/login.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1.解决POST请求中文乱码问题
		request.setCharacterEncoding("UTF-8");
		//2.获取客户端的数据
		String account = request.getParameter("account");
		String password = request.getParameter("password");
		//3.跟业务逻辑层建立联系 厨师建立联系
		UserService userService = new UserServiceImpl();//接口回调
		try {
			User user = userService.login(account, password);
			HttpSession session = request.getSession();
			session.setAttribute("session_user", user);

			response.sendRedirect(request.getContextPath()+"/sys/main");
		} catch (RuntimeException ex) {
			ex.printStackTrace();
			request.setAttribute("message", ex.getMessage());
			request.getRequestDispatcher("/WEB-INF/jsp/login.jsp").forward(request, response);

		}



	}

}
