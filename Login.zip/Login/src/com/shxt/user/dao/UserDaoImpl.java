package com.shxt.user.dao;

import java.util.HashMap;
import java.util.Map;
import org.apache.ibatis.session.SqlSession;
import com.shxt.user.model.User;
import com.shxt.util.MyBatisUtils;

public class UserDaoImpl implements UserDao {

	@Override
	public User login(String account,String password){
		SqlSession sqlSession = null;
		try {
			sqlSession = MyBatisUtils.getSqlSession();
			//4.封装数据
			Map<String,String> map = new HashMap<String,String>();
			map.put("account", account);
			map.put("password", password);
			return sqlSession.selectOne(User.class.getName()+".login", map);
		} finally {
			MyBatisUtils.closeSqlSession(sqlSession);
		}
	}

}
