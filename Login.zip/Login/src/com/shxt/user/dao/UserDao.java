package com.shxt.user.dao;

import com.shxt.user.model.User;

public interface UserDao {

	User login(String account,String password);

}
