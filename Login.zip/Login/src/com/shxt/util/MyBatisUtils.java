package com.shxt.util;

import java.io.IOException;
import java.io.InputStream;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/*
 知识点: final关键字的特点
 1.修饰的类不能被继承
 2.修饰的方法不能被重写
 3.修饰变量是常量
 */
public  final class MyBatisUtils{
	private MyBatisUtils(){}
	private final static String PATH = "mybatis-config.xml";

	private static SqlSessionFactory sqlSessionFactory;

	/*
	 知识点: static关键字的特点
	 1.不能修改时类
	 2.能修饰方法
	 3.如果修饰变量,共享数据
	 4.static的修饰是随着类的加载而加载,加载一次
	 5.只能是类方法或者类变量
	 */
	static{
		try {
			InputStream is = Resources.getResourceAsStream(PATH);

			sqlSessionFactory = new SqlSessionFactoryBuilder().build(is);
		} catch (IOException ex) {
			ex.printStackTrace();//控制台打印错误的信息信息
			//处理异常
			throw new RuntimeException("加载核心配置文件失败");
		}
	}

	public static SqlSession getSqlSession(){
		return sqlSessionFactory.openSession();
	}

	public static void closeSqlSession(SqlSession sqlSession){
		if(sqlSession!=null){
			sqlSession.close();
		}
	}


}

