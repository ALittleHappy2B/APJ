package com.ccut.mapper;

import java.util.List;

import com.ccut.page.Page;
import com.ccut.pojo.Student;

public interface StudentMapper {
	
	public List<Student> list();
   //分页查询
	public List<Student> list(Page page);
	
	public int total();
	
	//增加
	public void add(Student student);
	//删
	public void delete(Student student);
	//改
	public void update(Student student);
	//查
	public Student get(Student student);
	
}
