package com.ccut.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ccut.mapper.StudentMapper;
import com.ccut.pojo.Student;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class MybatisTest {
	/**
	 * Mybatis这个框架， 通过动态代理技术，创建了一个类，这个类实现了这个接口。
	 * 你可以在运行期间把categoryMapper这个引用打印出来，看看它指向了什么对象
	 */
	@Autowired
	private StudentMapper categoryMapper;

	@Test
	public void testList() {
		System.out.println(categoryMapper);
		List<Student> cs = categoryMapper.list();
		for (Student c : cs) {
			System.out.println(c.getName());
		}
	}
	
	//增加数据用来测试
	
	@Test
	public void add()
	{
		for(int i=0;i<100;i++)
		{
			Student student=new Student();
			student.setName("fei"+i);
			categoryMapper.add(student);
		}
	}

}
