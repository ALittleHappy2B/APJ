package com.ccut.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ccut.page.Page;
import com.ccut.pojo.Student;
import com.ccut.service.StudentService;

@org.springframework.stereotype.Controller
@RequestMapping("")
public class StudentController {
	@Autowired
	StudentService studentService;

	@RequestMapping("listStudent")
	public ModelAndView listStudent() {
		ModelAndView modelAndView = new ModelAndView();
		// 业务逻辑的实现
		List<Student> ls = studentService.list();
		modelAndView.addObject("cs", ls);
		modelAndView.setViewName("listStudent");
		return modelAndView;
	}

	@RequestMapping("listStudentBypage")
	public ModelAndView listStudentBypage(Page page) {
		ModelAndView modelAndView = new ModelAndView();
		// 业务逻辑的实现
		List<Student> ls = studentService.list(page);
		int total = studentService.total();
		page.caculateLast(total);
		modelAndView.addObject("cs", ls);
		modelAndView.setViewName("listStudent");
		return modelAndView;
	}

	// 增加
	@RequestMapping("addStudent")
	public ModelAndView addStudent(Student student) {
		studentService.add(student);
		ModelAndView mav = new ModelAndView("redirect:/listStudentBypage");
		return mav;
	}

	// 删除
	@RequestMapping("deleteStudent")
	public ModelAndView deleteStudent(Student student) {
		studentService.delete(student);
		ModelAndView mav = new ModelAndView("redirect:/listStudentBypage");
		return mav;
	}
   //修改,先通过get方法得到一个对象
	@RequestMapping("editStudent")
	public ModelAndView editStudent(Student student) {
		Student st = studentService.get(student.getId());
		System.out.println(st.toString());
		ModelAndView mav = new ModelAndView("editStudent");
		mav.addObject("c",st);
		return mav;
	}

	// 修改
	@RequestMapping("updateStudent")
	public ModelAndView updateStudent(Student student) {
        studentService.update(student);
		ModelAndView mav = new ModelAndView("redirect:/listStudentBypage");
		return mav;
	}

}
