package com.ccut.page;

public class Page {
	//开始第一个的页码
	int start=0;
	int count=5;
	//最后一页开始
	int end=0;
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getEnd() {
		return end;
	}
	public void setEnd(int end) {
		this.end = end;
	}
	/**
	 * 得到最后一页的数
	 * total:总共的数据
	 */

	public void caculateLast(int total)
	{
		if(0==total%count)
		{
			// 假设总数是50，是能够被5整除的，那么最后一页的开始就是45
			end=total-count;
		}else {
			 // 假设总数是51，不能够被5整除的，那么最后一页的开始就是50
			end=total-total%count;
		}
	}
}
