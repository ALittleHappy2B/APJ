package com.ccut.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ccut.mapper.StudentMapper;
import com.ccut.page.Page;
import com.ccut.pojo.Student;
import com.ccut.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	StudentMapper studentMapper;

	@Override
	public List<Student> list() {
		return studentMapper.list();
	}

	@Override
	public int total() {
		return studentMapper.total();
	}

	@Override
	public List<Student> list(Page page) {
		return studentMapper.list(page);
	}

	@Override
	public void add(Student student) {
		 studentMapper.add(student);
	}

	@Override
	public void delete(Student student) {
		studentMapper.delete(student);
	}

	@Override
	public void update(Student student) {
		studentMapper.update(student);
		
	}

	@Override
	public Student get(int id) {
		Student student=new Student();
		student.setId(id);
		return studentMapper.get(student);
	}

}
