package com.ccut.service;

import java.util.List;

import com.ccut.page.Page;
import com.ccut.pojo.Student;

public interface StudentService {
	List<Student> list();
	int total();
	List<Student> list(Page page);
	//增
	public void add(Student student);
	//删
	public void delete(Student student);
	//改
	public void  update(Student student);
	//查
	public Student  get(int id);
}
